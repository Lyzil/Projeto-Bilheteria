﻿using System;
using System.Collections.Generic;
using System.Data.Common;
using System.IO;
using System.Linq;
using System.Security.Cryptography.X509Certificates;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using static System.Windows.Forms.LinkLabel;

namespace projeto_Bilheteria
{
    internal class Bilheteria
    {
        private char[,] matriz = new char[15, 40];
        private string stmostra;
        private Random rnd = new Random();

        public Bilheteria()
        {
            for (int i = 0; i < 15; ++i)
            {
                for (int j = 0; j < 40; ++j)
                {
                    matriz[i,j] = '.'; // lembrar de usar '' no futuro
                }
            }
        }
        public string mostra_matriz()
        {
            stmostra = "";
            for (int i = 0; i < 15; ++i)
            {
                for (int j = 0; j < 40; ++j)
                {
                    stmostra += (matriz[i, j]) + " "; // colocar espaços
                }
                stmostra += "\n";
            }
            return stmostra + Environment.NewLine + ". = Livre | # = Reservado";
        }
        public void reservar_assento(string filaStr, string colunaStr)
        {
            try
            {
                int fila = Convert.ToInt32(filaStr);
                int coluna = Convert.ToInt32(colunaStr);

                if (fila < 0 || fila >= 15 || coluna < 0 || coluna >= 40)
                {
                    MessageBox.Show("Posição inválida! Tente novamente.", "Aviso",
                                    MessageBoxButtons.OK, MessageBoxIcon.Warning);
                    return;
                }

                if (matriz[fila, coluna] == '#')
                {
                    MessageBox.Show("Assento já ocupado! Escolha outro.", "Aviso",
                                    MessageBoxButtons.OK, MessageBoxIcon.Information);
                }
                else
                {
                    matriz[fila, coluna] = '#';
                    MessageBox.Show("Assento reservado com sucesso!", "Confirmação",
                                    MessageBoxButtons.OK, MessageBoxIcon.Information);
                }
            }
            catch (FormatException)
            {
                MessageBox.Show("Digite números válidos para fila e coluna.", "Erro de entrada",
                                MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }

        public void PreReservarAssentos()
        {
            int rf, rc;
            for (int i = 0; i < 200; ++i)
            {
                do
                {
                    rf = rnd.Next(0, 15);
                    rc = rnd.Next(0, 40);
                }
                while (matriz[rf, rc] == '#');

                matriz[rf, rc] = '#';
            }
        }
        public string Faturamento()
        {
            int qtd = 0;
            double valor_total = 0.0;


            for (int i = 0; i < 15; ++i)
            {
                for (int j = 0; j < 40; ++j)
                {
                    if (matriz[i,j] == '#')
                    {
                        qtd++;

                        if (i < 5)
                        {
                            valor_total += 50.00; //  1-5
                        }
                        else if (i < 10)
                        {
                            valor_total += 30.00; //  6-10
                        }
                        else
                        {
                            valor_total += 15.00; //  11-15
                        }
                    }
                }
            }
            return "Qtde de lugares ocupados: " + qtd + Environment.NewLine + "Valor da bilheteria: R$ " + valor_total.ToString("F2");
        }
    }
}
