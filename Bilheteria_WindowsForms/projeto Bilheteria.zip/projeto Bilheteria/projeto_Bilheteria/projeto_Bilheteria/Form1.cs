﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace projeto_Bilheteria
{
    public partial class Form1 : Form
    {
        private Button btnFinalizar;
        private Button btnReservar;
        private Button btnFaturamento;
        private Label labelReservar;
        private Label labelMostrar;
        private Label labelFaturamento;
        private TextBox txtReservar1;
        private TextBox txtReservar2;

        Bilheteria bilheteria = new Bilheteria();

        public Form1()
        {
            InitializeComponent();
            InitializeMyComponents();
        }

        private void InitializeMyComponents()
        {
            btnFinalizar = new Button();
            btnReservar = new Button();
            btnFaturamento = new Button();
            labelReservar = new Label();
            labelMostrar = new Label();
            labelFaturamento = new Label();
            txtReservar1 = new TextBox();
            txtReservar2 = new TextBox();
            btnFinalizar.Parent = this;
            btnReservar.Parent = this;
            btnFaturamento.Parent = this;
            labelReservar.Parent = this;
            labelMostrar.Parent = this;
            labelFaturamento.Parent = this;
            txtReservar1.Parent = this;
            txtReservar2.Parent = this;
            btnFinalizar.Text = "Finalizar";
            btnFinalizar.Left = 120;
            btnFinalizar.Top = 250;

            btnReservar.Text = "Reservar assento";
            btnReservar.Left = 105;
            btnReservar.Top = 50;
            btnReservar.AutoSize = true;
            btnReservar.MaximumSize = new Size(250, 0);
            labelReservar.Text = "Digite a linha e coluna a ser reservada abaixo (linha(0-14) coluna (0-39))";
            labelReservar.Left = 40;
            labelReservar.Top = 80;
            labelReservar.AutoSize = true;
            labelReservar.MaximumSize = new Size(250, 0);
            labelReservar.TextAlign = ContentAlignment.MiddleCenter;
            txtReservar1.Left = 50;
            txtReservar2.Left = 160;
            txtReservar1.Top = 110;
            txtReservar2.Top = 110;

            btnFaturamento.Text = "Mostrar Faturamento";
            btnFaturamento.Left = 105;
            btnFaturamento.Top = 180;
            btnFaturamento.AutoSize = true;
            btnFaturamento.MaximumSize = new Size(250, 0);
            labelFaturamento.Text = "Veja o faturamento aqui";
            labelFaturamento.Left = 85;
            labelFaturamento.Top = 210;
            labelFaturamento.AutoSize = true;
            labelFaturamento.MaximumSize = new Size(250, 0);

            labelMostrar.Text = bilheteria.mostra_matriz();
            labelMostrar.Left = 300;
            labelMostrar.Top = 50;
            labelMostrar.AutoSize = false;
            labelMostrar.Font = new Font(FontFamily.GenericMonospace, 8);
            labelMostrar.Size = new Size(570, 250);
            labelMostrar.BorderStyle = BorderStyle.FixedSingle;

            btnFinalizar.Click += new EventHandler(clickFinalizar);
            btnReservar.Click += new EventHandler(clickReservar);
            btnFaturamento.Click += new EventHandler(clickFaturamento);
        }

        private void Form1_Load(object sender, EventArgs e)
        {
            bilheteria.PreReservarAssentos();
            labelMostrar.Text = bilheteria.mostra_matriz();
        }

        private void clickFaturamento(object sender, EventArgs e)
        {
            labelFaturamento.Text = bilheteria.Faturamento();
        }

        private void clickReservar(object sender, EventArgs e)
        {
            bilheteria.reservar_assento(txtReservar1.Text,txtReservar2.Text);
            labelMostrar.Text = bilheteria.mostra_matriz();
        }

        private void clickFinalizar( object sender, EventArgs e)
        {
            Application.Exit();
        }
    }
}
